package com.cg.ata.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComCgAtaProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
